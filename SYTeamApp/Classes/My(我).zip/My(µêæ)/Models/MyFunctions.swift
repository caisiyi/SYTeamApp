//
//  MyFunctions.swift
//  SYTeamApp
//
//  Created by mac on 16/4/12.
//  Copyright © 2016年 caisiyi. All rights reserved.
//

import Foundation
class MyFunctionModel: NSObject {
    var MyFunctionImage:String?
    var MyFunctionName:String?

}