//
//  MyCodeViewController.swift
//  PersonInformation
//
//  Created by MAC on 16/4/13.
//  Copyright © 2016年 MAC. All rights reserved.
//

import UIKit

class MyCodeViewController: UIViewController {
    lazy var CodeImageView : UIImageView = {
            let imageview = UIImageView()
        imageview.image = UIImage(named: "3最热")
        return imageview
        }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0.9, alpha: 1)
        self.title = "我的二维码"
        let leftItem = UIBarButtonItem(title: "取消", style: .Plain, target: self, action: "cancel")
        self.navigationItem.leftBarButtonItem = leftItem
        view.addSubview(CodeImageView)
        CodeImageView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(84)
            make.left.equalTo(20)
            make.right.equalTo(-20)
            make.height.equalTo(160)
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func cancel(){
        self.navigationController?.popViewControllerAnimated(true)
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
